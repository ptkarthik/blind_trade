
import type { Signal } from './DealCard';
import { ShieldCheck, Activity, Clock } from 'lucide-react';

interface StockCardLongTermProps {
    signal: Signal;
    rank?: number;
    onClick: () => void;
    onBuy?: (e: React.MouseEvent, tradeType: 'PAPER' | 'REAL') => void;
}

export function StockCardLongTerm({ signal, rank, onClick, onBuy }: StockCardLongTermProps) {
    if (!signal) return null;

    const isBuy = signal.signal === "BUY";

    // --- COLOR THEME (Professional & Clean) ---
    const baseColor = isBuy
        ? "bg-white border-emerald-100 hover:border-emerald-300 shadow-sm hover:shadow-emerald-100/50"
        : "bg-white border-slate-200 hover:border-slate-300 shadow-sm";

    // Paid App Feature Extraction - Defensive
    const alphaIntel = signal.alpha_intel || {};
    // Cast to any to avoid TS errors with empty object fallback
    const advisory = signal.investment_advisory || {} as any;
    const holding = advisory.holding_period || {};

    // Robust extraction for reasons
    const safeReasons = Array.isArray(signal.reasons) ? signal.reasons : [];

    // Safely extract RS Rating
    const rsReason = safeReasons.find(r => r && typeof r.text === 'string' && r.text.includes("RS"));
    const rsRating = rsReason?.value ? String(rsReason.value).replace("RS ", "") : "N/A";

    // Safely extract VCP
    const isVCP = safeReasons.some(r => r && typeof r.text === 'string' && r.text.includes("VCP"));

    // Safely extract Sponsorship
    const instReason = safeReasons.find(r => r?.label === "INSTITUTIONAL");
    const sponsorship = instReason?.value || "Neutral";


    return (
        <div
            onClick={onClick}
            className={`relative border rounded-2xl p-4 transition-all duration-300 cursor-pointer group hover:-translate-y-1 ${baseColor}`}
        >
            {/* --- HEADER: Identity & Badges --- */}
            <div className="flex justify-between items-start mb-4">
                <div className="flex items-center gap-3">
                    {rank !== undefined && (
                        <div className={`flex items-center justify-center w-8 h-8 rounded-lg font-bold text-sm ${isBuy ? 'bg-emerald-600 text-white' : 'bg-slate-600 text-white'}`}>
                            #{rank}
                        </div>
                    )}
                    <div>
                        <h3 className="text-lg font-black tracking-tight text-slate-800">{signal.symbol}</h3>
                        <div className="flex items-center gap-2 mt-0.5">
                            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                                {String(signal.market_cap_category || '---')} • {String(signal.sector || '---')}
                            </span>
                        </div>
                    </div>
                </div>

                {/* PAID APP BADGES */}
                <div className="flex flex-col items-end gap-1">
                    <div className="flex gap-1">
                        {rsRating !== "N/A" && (
                            <span className="text-[10px] font-black px-1.5 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-100" title="Relative Strength Rating (0-99)">
                                RS {rsRating}
                            </span>
                        )}
                        {isVCP && (
                            <span className="text-[10px] font-black px-1.5 py-0.5 rounded bg-purple-50 text-purple-700 border border-purple-100 animate-pulse">
                                💎 VCP
                            </span>
                        )}
                    </div>
                    {sponsorship !== "Neutral" && (
                        <span className="text-[9px] font-bold text-slate-500 flex items-center gap-1">
                            <Activity size={10} /> Inst. {String(sponsorship)}
                        </span>
                    )}
                </div>
            </div>

            {/* --- ACTION ZONE (The "Trade" Setup) --- */}
            <div className="grid grid-cols-4 gap-2 py-3 border-t border-slate-100">
                <div className="flex flex-col gap-0.5">
                    <span className="text-[8px] sm:text-[9px] uppercase font-bold text-slate-400">LTP</span>
                    <span className="font-mono font-bold text-slate-600 text-xs sm:text-base">
                        {typeof signal.price === 'number' ? `₹${signal.price.toLocaleString('en-IN', { maximumFractionDigits: 2 })}` : '---'}
                    </span>
                </div>

                <div className="flex flex-col gap-0.5 border-l border-slate-100 pl-2">
                    <span className="text-[8px] sm:text-[9px] uppercase font-bold text-emerald-500">Entry</span>
                    <span className="font-mono font-bold text-emerald-600 text-xs sm:text-base">
                        {typeof signal.entry === 'number' ? `₹${signal.entry.toLocaleString('en-IN', { maximumFractionDigits: 2 })}` : '---'}
                    </span>
                </div>

                <div className="flex flex-col gap-0.5 border-l border-slate-100 pl-2">
                    <span className="text-[8px] sm:text-[9px] uppercase font-bold text-red-500">Stop Loss</span>
                    <span className="font-mono font-bold text-red-600 text-xs sm:text-base">
                        {typeof signal.stop_loss === 'number' ? `₹${signal.stop_loss.toLocaleString('en-IN', { maximumFractionDigits: 2 })}` : '---'}
                    </span>
                </div>

                <div className="flex flex-col gap-0.5 border-l border-slate-100 pl-2">
                    <span className="text-[8px] sm:text-[9px] uppercase font-bold text-blue-500">Target</span>
                    <span className="font-mono font-bold text-blue-600 text-xs sm:text-base">
                        {typeof signal.target === 'number' ? `₹${signal.target.toLocaleString('en-IN', { maximumFractionDigits: 2 })}` : '---'}
                    </span>
                </div>
            </div>

            {/* --- MAIN METRICS GRID (Investment Grade) --- */}
            <div className="grid grid-cols-2 gap-4 py-4 border-t border-slate-100">

                {/* 1. Quality & Value */}
                <div className="space-y-1">
                    <p className="text-[10px] uppercase font-bold text-slate-400">Fundamentals</p>
                    <div className="flex flex-col gap-1">
                        <div className="flex justify-between text-xs">
                            <span className="text-slate-500">Quality</span>
                            <span className="font-bold text-slate-700">{alphaIntel.quality_score || 'N/A'}/100</span>
                        </div>
                        <div className="flex justify-between text-xs">
                            <span className="text-slate-500">Valuation</span>
                            <span className={`font-bold ${typeof alphaIntel.valuation_status === 'string' && alphaIntel.valuation_status.includes("Attractive") ? "text-emerald-600" : "text-amber-600"}`}>
                                {String(alphaIntel.valuation_status || "---")}
                            </span>
                        </div>
                    </div>
                </div>

                {/* 2. Strategic Horizon */}
                <div className="space-y-1 border-l border-slate-100 pl-4">
                    <p className="text-[10px] uppercase font-bold text-slate-400">Horizon</p>
                    <div className="flex items-center gap-1.5 mt-1">
                        <Clock size={14} className="text-slate-400" />
                        <span className="text-xs font-bold text-slate-700">
                            {holding.period_display || "3-5 Years"}
                        </span>
                    </div>
                    {holding.play_type && (
                        <span className="inline-block mt-1 text-[9px] font-bold px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 uppercase">
                            {String(holding.play_type)}
                        </span>
                    )}
                </div>
            </div>

            {/* --- STRATEGIC VERDICT (The "One Liner") --- */}
            <div className={`mt-2 p-3 rounded-xl border-l-4 ${isBuy ? "bg-emerald-50/50 border-emerald-500" : "bg-slate-50 border-slate-400"}`}>
                <p className="text-xs font-medium text-slate-700 leading-relaxed italic">
                    "{String(signal.strategic_summary || signal.verdict || '---')}"
                </p>
            </div>

            {/* --- FOOTER: Actions --- */}
            <div className="mt-4 flex items-center justify-between">
                <div className="flex gap-2">
                    {/* Dynamic Tags */}
                    {alphaIntel.moat_status === "Wide" && (
                        <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-amber-50 text-amber-700 border border-amber-100 flex items-center gap-1">
                            <ShieldCheck size={10} /> Wide Moat
                        </span>
                    )}
                    {signal.score > 80 && (
                        <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-100">
                            High Conviction
                        </span>
                    )}
                </div>

                <div className="flex items-center gap-2">
                    {onBuy && (
                        <div className="flex gap-1 z-20">
                            <button 
                                onClick={(e) => {
                                    e.stopPropagation();
                                    onBuy(e, 'PAPER');
                                }}
                                className="text-[10px] font-black uppercase px-3 py-1.5 rounded border transition-all text-emerald-600 bg-emerald-50 border-emerald-100 hover:bg-emerald-500 hover:text-white"
                            >
                                BUY (PAPER)
                            </button>
                            <button 
                                onClick={(e) => {
                                    e.stopPropagation();
                                    if(confirm("⚠️ Place REAL LIVE ORDER on Zerodha?")) onBuy(e, 'REAL');
                                }}
                                className="text-[10px] font-black uppercase px-3 py-1.5 rounded border transition-all shadow-sm text-white bg-emerald-600 border-emerald-700 hover:bg-emerald-700"
                            >
                                BUY (REAL)
                            </button>
                        </div>
                    )}
                    <button className={`text-xs font-bold px-4 py-2 rounded-lg text-white shadow-sm hover:shadow-md transition-all ${isBuy ? "bg-emerald-600 hover:bg-emerald-700" : "bg-slate-600 hover:bg-slate-700"}`}>
                        Analysis Report
                    </button>
                </div>
            </div>
        </div>
    );
}
